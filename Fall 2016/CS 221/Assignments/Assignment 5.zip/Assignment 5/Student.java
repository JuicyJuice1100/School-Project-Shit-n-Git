
/**
 * A class that keeps track of a Student
 * 
 * @author George Thomas
 * @version (12/05/2016)
 */
public class Student
{
   private String studentID;
   private FullName name;
   
   public Student(String s, FullName n)
   {
       studentID = s;
       name = n;
   }
   
   //Accessors
   public String getStudentID()
   {
       return studentID;
   }

   public FullName getName()
   {
       return name;
   }
   
   //Mutators
   public void setStudentID(String s)
   {
       studentID = s;
   }

   public void setName(FullName n)
   {
       name = n;
   }
   
   public String toString()
   {
       return "Student ID:"+studentID+", "+name;
   }
   
   public boolean equals (Object obj)
   {
       if (obj instanceof Student)
       {
           Student s = (Student)obj;
           return studentID.equals(s.getStudentID());
       }
       return false;
   }
}
