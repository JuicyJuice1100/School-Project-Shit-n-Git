/*
Justin Espiritu
12/8/2016

Class that keeps track of students in a course
*/

public class Course
{
    //course name and number
    private String name, number;
    private int enrollment, maxEnrollment;
    private Student[] roster;

    public Course(String cNumber, String cName, int maximumEnrollment)
    {
        number = cNumber;
        name = cName;
        maxEnrollment = maximumEnrollment;
        roster = new Student[maxEnrollment];
        enrollment = 0;
    }

    public String getName()
    {
        return name;
    }

    public String getNumber() 
    {
        return number;
    }

    //Can we add the student?
    public boolean add(Student student)
    {
    	//Is course Full?
        if(isFull() == false)
        {	
        	//Student already in the class?
            for(Student s : roster)
            {
              	//Check for null objects
              	if(s != null)
              	{	
              		//Check for identical studenID's
	            	if(student.equals(s) == true)
	            	{
	            		return false;
	            	}           	
            	}
            }
            for(int i = 0; i < roster.length; i++)
            {
            	if(roster[i] == null)
            	{
            		roster[i] = student;
            		enrollment ++;
            		return true;
            	}
            }
        }
        return false;
    }

    //Is Course Full?
    public boolean isFull()
    {
        if(enrollment < maxEnrollment)
        {
            return false;
        }
        return true;
    }

    public void printRoster()
    {     
        for(Student s : roster)
        {
        	if(s != null)
        	{
            	System.out.printf("%-5s %-10s %-10s %-10s\n", s.getStudentID(), s.getName().getFirst(), s.getName().getMiddle(), s.getName().getLast());
        	}
        }
    }
}