
/**
 * A driver class that provides a menu based option to add and delete students from a course
 * 
 * @author George Thomas
 * @version (12/05/2016) 
*/
import java.util.Scanner;
public class Driver
{    
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        String choice="S";
                
        Course course = null;
        
        while(!choice.equalsIgnoreCase("Q"))
        {
            displayOptions(course);
            choice = scan.next();
            if (choice.equalsIgnoreCase("S"))
            {
                System.out.println("Please enter course details: ");
                System.out.print("Course Number: ");
                String number = scan.next();
                System.out.print("Course Name, no spaces please: ");
                String name = scan.next();
                System.out.print("Maximum Enrollment: ");
                int maxEnrollment = scan.nextInt();
                course = new Course(number, name, maxEnrollment);
                System.out.println("Course created");
            }
            else if (choice.equalsIgnoreCase("Q"))
            {
                    System.out.println("Terminating program.\nGoodbye");
            }
            else if (course==null && (choice.equalsIgnoreCase("A") || 
                    choice.equalsIgnoreCase("P") || choice.equalsIgnoreCase("F")) )
            {
                System.out.println("Please set up a course first");
                continue;
            }
            else if (choice.equalsIgnoreCase("A"))
            {
                System.out.println("Please enter the first, middle and last names of the student, in that order: ");
                String first = scan.next();
                String middle = scan.next();
                String last = scan.next();
                FullName name = new FullName(first, middle, last);
                System.out.println("Now enter the ID of the student");
                System.out.print("Student ID: ");
                String id = scan.next();
                Student student = new Student(id, name);
                boolean success = course.add(student);
                if (success)
                {
                    System.out.println("Student added to course");
                }
                else
                {
                    System.out.println("Course full or student already in course. Add failed");
                }

            }
            else if (choice.equalsIgnoreCase("P"))
            {
                System.out.println("Roster for "+ course.getNumber()+": "+course.getName());
                course.printRoster();
            }
            else if (choice.equalsIgnoreCase("F"))
            {
                 if (course.isFull())
                    System.out.println("This course is full");
                 else
                    System.out.println("This course is still not full");
            }
            else
            {
                System.out.println("Invalid option. Please choose again: ");
            }
        }
    }
    
    private static void displayOptions(Course course)
    {

        System.out.println("\nCurrent Course Name:");
        if (course != null)
            System.out.println(course.getNumber()+": "+course.getName());
        else 
            System.out.println("No course set up");
        System.out.println("The following options are available:");   
        System.out.println("------------------------------------"); 
        System.out.println("S: set up a new course\nA: add a student to the current course\nD: drop a student from the current course\nP: print the roster of the current course\nF: check if course is full\nQ: quit program");  
        System.out.println("------------------------------------"); 
        System.out.println("Please select a choice: ");
    }

}
