
/**
 * Justin Espiritu
 * 10/26/2016
 * 
 * This program will take a list of scores to give them a letter grading, average them, provide
 * the minimum and maximum, and the total number of A, B, C, D, and F grades.
 */
import java.util.Scanner;

public class GradeSummator
{
    public static void main(String[] args)
    {
        //variables
        Scanner scan = new Scanner(System.in);
        int numOfScores, max, min, nextScore, gradeA = 0, gradeB = 0, gradeC= 0, gradeD = 0, gradeF = 0;
        double avg = 0;
        max = Integer.MIN_VALUE;
        min = Integer.MAX_VALUE;
        
        System.out.println("Enter number of scores followed by scores (5 81 91 93 78 63)");
        numOfScores = scan.nextInt();
        for (int counter = 0; counter < numOfScores; counter ++)
        {
            nextScore = scan.nextInt();
            avg += nextScore;
            
            // find number of A's, B's, C's, ...
            if (nextScore >= 91)
            {
                gradeA ++;
            }
            else if (nextScore <91 && nextScore >= 83)
            {
                gradeB ++;
            }
            else if (nextScore < 83 && nextScore >= 75)
            {
                gradeC ++;
            }
            else if (nextScore < 75 && nextScore >= 67)
            {
                gradeD ++;
            }
            else
            {
                gradeF ++;
            }
            
            // find min and max
            if (nextScore > max)
            {
                max = nextScore;
            }
            else if (nextScore < min)
            {
                min = nextScore;
            }
        }
        avg = avg / numOfScores;
        System.out.println("Grade Summary:");
        System.out.println("A's: " + gradeA);
        System.out.println("B's: " + gradeB);
        System.out.println("C's: " + gradeC);
        System.out.println("D's: " + gradeD);
        System.out.println("F's: " + gradeF);
        System.out.println("Minimum Score: " + min);
        System.out.println("Maximum Score: " + max);
        //ToDo print avg only to 2 decimal places
        System.out.printf("Average Score: %.2f", avg);
    } //end main
} // end class GradeSummator
   