/*
Justin Espiritu
12/02/16

Class that creates circle in a 2d plain
*/

public class Circle
{
	int radius;
	Point2D center;

	public Circle(int radius, Point2D center)
	{
		this.radius = radius;
		this.center = center;
	}

	//accessor for Radius
	public int getRadius()
	{
		return radius;
	}

	//accessor for Center
	public Point2D getCenter()
	{
		return center;
	}

	//Mutator for Radius
	public void setRadius(int radius)
	{
		this.radius = radius;
	}

	//Mutator for Center
	public void setCenter(Point2D center)
	{
		this.center = center;
	}

	public String toString()
	{
		return "radius = " + getRadius() + center.toString();
	}

	//See if two object are equal
	public boolean equals(Object o)
	{
		if (o instanceof Circle)
		{
			Circle circle = (Circle)o;
			if(radius == circle.getRadius() && this.center.equals(center) == true)
			{
				return true;
			}
		}
		return false;
	}

	public double computeArea()
	{
		return Math.PI * radius * radius;
	}

	public double computeCircumference()
	{
		return 2 * Math.PI * radius;
	}

	public boolean intersects(Circle other)
	{
	    //clarifying the object centers as variables
		Point2D centerOne = other.getCenter();
		Point2D centerTwo = getCenter();
		
		//distance between the two centers
		double distance = Math.sqrt(Math.pow(centerOne.getX() - centerTwo.getX(), 2) + Math.pow(centerOne.getY() - centerTwo.getY(), 2));
		if (other instanceof Circle)
		{
			Circle circle = (Circle)other;
			//checks if circle interescts
			if (radius + other.getRadius() < distance || radius > other.getRadius() + distance || other.getRadius() > radius + distance)
			{
				return false;
			}
		}
		return true;
	}
}