/*
Justin Espiritu
12/02/16

Class creates points on a 2d plain
*/

public class Point2D
{
	int x, y;

	public Point2D(int x, int y)
	{
		this.x = x;
		this.y = y;
	}

	//accessor for x
	public int getX()
	{
		return x;
	}

	//accessor for y
	public int getY()
	{
		return y;
	}

	//return a string in format <x, y>
	public String toString()
	{
		return "<" + getX() + ", " + getY() + ">";
	}

	//see if two objects are equal
	public boolean equals(Object o)
	{
		if (o instanceof Point2D)
		{
			Point2D center = (Point2D)o;
			if (x == center.getX() && y == center.getY())
			{
				return true;
			}
		}
		return false;
	}
}