
/**
 * Justin Espiritu
 * 10/12/2016
 * 
 * a simple calculator that will take an expression entered by the user 
 * and output the expression with the answer in english (Ex. Input: 12.0 - 5 Output: 12.0 minus 5 is 7)
 * 
 * Algorithm
 * Input: Expression
 * Output: Expression w/ answer in English (Example: 12 minus 5 is 7)
 * Assumptions: User will input expression with proper spaces (Example: 3 ^ 3) 
 * 
 * Steps:
 *      Input:
 *          - prompt user to input expression
 *          - first number <- extract from expression
 *          - operator <- extract from expression
 *          - second number <- extract from expression
 *          
 *      Process:
 *          - add, subtract, multiply, divide, and use exponents using the first and second numbers
 *          - find out which answer to put as output by using if, else statements
 *          - if division make sure expression is not dividing by 0
 *      
 *      Output:
 *          - print out answer or error if divided by 0 
 */
import java.util.Scanner;

public class Calculator
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        String op; //op = operator
        double answer, firstNum, secondNum, add, sub, mult, div, exp;
        
        System.out.println("Enter an expression");
        firstNum = scan.nextDouble();
        op = scan.next();
        secondNum = scan.nextDouble();
        add = firstNum + secondNum;
        sub = firstNum - secondNum;
        mult = firstNum * secondNum;
        div = firstNum / secondNum;
        exp = Math.pow(firstNum, secondNum); 
        
        if (op.equals("+"))
        {
            System.out.println(firstNum + " plus " + secondNum + " is " + add);
        }
        else if (op.equals("-"))
        {
            System.out.println(firstNum + " minus " + secondNum + " is " + sub);
        }
        else if (op.equals("*"))
        {
            System.out.println(firstNum + " multiplied by " + secondNum + " is " + mult);
        }
        else if (op.equals("/"))
        {
            if (secondNum == 0)
            {
                System.out.println("Division by zero is not allowed");
            }
            else 
            {
            System.out.println(firstNum + " divided by " + secondNum + " is " + div);
            }
       }
        else 
        {
            System.out.println(firstNum + " to the power " + secondNum + " is " + exp);
        }
    }// end main
}// end class Calculator
   