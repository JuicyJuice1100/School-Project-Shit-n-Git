/*
Justin Espiritu
11/17/2016

This class allows a game to be created, the status stored, 
and enables the Computer and you to play turns
*/

import java.util.Random;

public class MindReader
{
	private int maxTurns, currTurns, correctGuesses, incorrectGuesses;
	private String lastGuess;
	private boolean isLastGuessRight;

	//constructor
	public MindReader(int maxTurns, int currTurns, int correctGuesses, int incorrectGuesses, String lastGuess, boolean isLastGuessRight)
	{
		this.maxTurns = maxTurns;
		this.currTurns = currTurns;
		this.correctGuesses = correctGuesses;
		this.incorrectGuesses = incorrectGuesses;
		this.lastGuess = lastGuess;
		this.isLastGuessRight = isLastGuessRight;
	}

	//Method sees if game is over
	public boolean isGameOver()
	{
		if(maxTurns == currTurns)
		{
			return true;
		}
		return false;
	}

	//Accessors
	public int getCorrectGuesses()
	{
		return correctGuesses;
	}

	public int getIncorrectGuesses()
	{
		return incorrectGuesses;
	}

	//mutators
	public void setCorrectGuesses()
	{
		correctGuesses ++;
	}

	public void setIncorrectGuesses()
	{
		incorrectGuesses ++;
	}

	public void setLastGuess(String lastGuess)
	{
		this.lastGuess = lastGuess;
	}

	public void setCurrTurns(int currTurns)
	{
		this.currTurns = currTurns;
	}

	public void setIsLastGuessRight(boolean isLastGuessRight)
	{
		this.isLastGuessRight = isLastGuessRight;
	}

	//computer makes a guess
	public void makeNextGuess()
	{
		Random rand = new Random();
		int guess = rand.nextInt(2);
		if(guess == 1)
		{
			setLastGuess("H");
		}
		else
		{
			setLastGuess("T");
		}

	}

	//was computer's guess correct?
	public boolean guessedRight()
	{
		if(isLastGuessRight == true)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	//updates score using LastGuess and updates isLastGuessRight() method
	public void updateScore(String userChoice)
	{
		if(userChoice.equals(lastGuess))
		{
			setCorrectGuesses();
			setIsLastGuessRight(true);
		}
			
		else
		{
			setIncorrectGuesses();
			setIsLastGuessRight(false);
		}
	}
}