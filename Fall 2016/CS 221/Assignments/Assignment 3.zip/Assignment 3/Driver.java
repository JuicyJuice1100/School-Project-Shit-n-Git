/*
Justin Espiritu
11/17/2016

This Driver will play a game by creating an object of MindReader class
and using this object to play the game
*/

import java.util.Scanner;

public class Driver
{
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		int maxTurns;
		String userChoice, score;

		System.out.println("How many times do you want to play this game?");
		maxTurns = scan.nextInt();

		MindReader game = new MindReader(maxTurns, 1, 0, 0, "", false);

		//updating the variable score
		score = String.format("You: %-5d Computer: %d", game.getIncorrectGuesses(), game.getCorrectGuesses());
		System.out.println(score);

		//loop until the game is over
		do
		{
			//loop as many times as user input
			for(int currTurns = 1; currTurns <= maxTurns; currTurns ++)
			{
				System.out.println("Choose H or T");
				userChoice = scan.next();

				//Computer will make guess first then will update score in the MindReader class
				game.makeNextGuess();
				game.updateScore(userChoice);

				//will print out if computer guessed correctly or not
				if(game.guessedRight() == true)
				{
					System.out.println("Computer guessed correctly");
				}
				else
				{
					System.out.println("Computer guessed wrongly");
				}

				//updating score variable
				score = String.format("You: %-5d Computer: %d", game.getIncorrectGuesses(), game.getCorrectGuesses());
				System.out.println(score);

				//update current turns in the MindReader Class
				game.setCurrTurns(currTurns);
			}
		} while(game.isGameOver() == false);
		
		//printing out game over, score and if user lost or won
		if(game.getIncorrectGuesses() < game.getCorrectGuesses())
		{
			System.out.printf("Game over; you lost %d to %d", game.getIncorrectGuesses(), game.getCorrectGuesses());
		}
		else if(game.getIncorrectGuesses() > game.getCorrectGuesses())
		{
			System.out.printf("Game over; you won %d to %d", game.getIncorrectGuesses(), game.getCorrectGuesses());
		}
		else
		{
			System.out.printf("Game over; tie game %d to %d", game.getIncorrectGuesses(),game.getCorrectGuesses());
		}
	}
}