
/**
 * Justin Espiritu
 * 10/27/16
 * 
 * Program takes the users first, middle, and last name and prints out their initials
 */
import java.util.Scanner;

public class Initials
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        String first, middle, last;
        
        System.out.println("Enter First, Middle, Last name with spaces(Justin Leonard Espiritu)");
        first = scan.next().toUpperCase();
        middle = scan.next().toUpperCase();
        last = scan.next().toUpperCase();
        
        System.out.println(first.substring(0,1) + "." + middle.substring(0,1) + "." + last.substring(0,1) + ".");
    }//end main
}//end class Initials
 