
/**
 * Justin Espiritu
 * 10/27/16
 * 
 * Program takes a string from user and replaces target string(s) with string provided by user.
 */
import java.util.Scanner;
public class ReplacerShortcut
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        String input, target, replacer, firstPiece, secondPiece, thirdPiece;
        int posn = 0;
        
        System.out.println("Enter string");
        input = scan.nextLine();
        System.out.println("Enter target string");
        target = scan.next();
        System.out.println("Enter replacer");
        replacer = scan.next();
        
        input = input.replaceAll(target, replacer);
        
        System.out.print(input);
    }//end main
}//end class Replacer