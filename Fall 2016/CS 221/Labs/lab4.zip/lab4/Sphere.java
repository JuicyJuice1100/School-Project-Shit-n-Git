
/**
 * 9/29/2016
 * Justin Espiritu
 * 
 * User inputs the radius and program will output the volume of a sphere
 */
import java.util.Scanner;

public class Sphere
{
   public static void main(String[] args)
   {
       Scanner scan = new Scanner(System.in);
       double radius, sphere;
       
       //Input
       System.out.println("Enter radius of circle");
       radius = scan.nextDouble();
       
       //Process
       sphere = 4/3 * Math.PI * Math.pow(radius, 3);
       
       //Output
       System.out.println("The Area of the Sphere = " + sphere);
    }//end main
}//end class Sphere
       
       
       