
/**
 * 9/29/2016
 * Justin Espiritu
 * 
 * This program calculates the nth number of the fibonacci sequence
 */
import java.util.Scanner;

public class Fibonacci
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        int number, finalPosition; //number = position of number we are looking for.
        double posForm, negForm, position; //posForm = first half of formula. negForm = second half of formula.
        final double sqrtFive = Math.sqrt(5);
        
        //input
        System.out.println("Enter position of number you want: "); 
        number = scan.nextInt();
        
        //process
        posForm = (1 + sqrtFive)/2; 
        posForm = Math.pow(posForm, number);
        negForm = (1 - sqrtFive)/2;
        negForm = Math.pow(negForm, number);
        position = 1/sqrtFive * (posForm - negForm);
        finalPosition = (int)position;
        
        //output
        System.out.println("Number in position: " + finalPosition);
    }//end main
}//end class Fibonacci
        
        
   