/**
 *Justin Espiritu
 *10/20/16
 *
 *Prgram will find and print out the Min and Max numbers taken from number given by the user
 */
import java.util.Scanner;

public class MinMax
{
    public static void main(String[] args)
    {
       Scanner scan = new Scanner(System.in);
       int howMany;
       double max, min, next; //next = number in sequence
       
       System.out.println("How many numbers do you want to enter?");
       howMany = scan.nextInt();
       System.out.println("Enter numbers with spaces (1 2 3 ...)");
       
       max = scan.nextInt();
       min = max;
       
       for (int counter = 1; counter < howMany; counter ++)
       {
           next = scan.nextDouble();
           if (next > max)
           {
               max = next;
           }
           else if (next < max)
           {
               min = next;
           }
       }
       System.out.println("Max = " + max + " Min = " + min); 
    }// end main
}// end class Sum
  