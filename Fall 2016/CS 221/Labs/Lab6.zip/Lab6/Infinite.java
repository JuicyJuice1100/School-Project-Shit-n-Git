/**
 *Justin Espiritu
 *10/20/16
 *
 *Prgram will find and print out the Min and Max numbers taken from number given by the user
 */
import java.util.Scanner;

public class Infinite
{
    public static void main(String[] args)
    {
       Scanner scan = new Scanner(System.in);
       int n;
       double sum = 0;
       
       System.out.println("Enter how many terms you want");
       n = scan.nextInt();

       for (double counter = 1; counter <= n && counter < 3; counter ++)
       {
           sum += 1/counter;
       }
       for (double counter = 2; counter < n; counter ++)
       {
           sum += 1/(counter*counter);
       }
       System.out.println("Sum of " + n + " terms = " + sum);
    }// end main
}// end class Sum
  