/*
*Justin Espiritu
*11/17/2016
*
*Simulates a clock
*/

public class Clock
{
	private int hours, minutes, seconds;
	
	//mutators
	public void setHours(int hours)
	{
		if (hours < 0 || hours > 23)
		{
			this.hours = 0;
		}
		else
		{
			this.hours = hours;
		}
	}
	public void setMinutes(int minutes)
	{
		if (minutes < 0 || minutes > 59)
		{
			this.minutes = 0;
		}
		else
		{
			this.minutes = minutes;
		}
	}
	public void setSeconds(int seconds)
	{
		if (seconds < 0 || seconds > 59)
		{
			this.seconds = 0;
		}
		else
		{
			this.seconds = seconds;
		}
	}

	//contructor
	public Clock(int hours, int minutes, int seconds)
	{
		setHours(hours);
		setMinutes(minutes);
		setSeconds(seconds);
	}

	//accessors
	public int getHours()
	{
		return hours;
	}
	public int getMinutes()
	{
		return minutes;
	}
	public int getSeconds()
	{
		return seconds;
	}

	public String toString()
	{
		String str = String.format("%02d:%02d:%02d", hours, minutes, seconds);
		return str;
	}

	public boolean equals(Object o)
	{
		if (o instanceof Clock)
		{
			Clock clock = (Clock)o;
			if (hours == clock.getHours() && minutes == clock.getMinutes() && seconds == clock.getSeconds())
			{
				return true;
			}
		}
		return false;
	}

	public String tick()
	{
		setSeconds(this.seconds + 1);
			if (seconds == 0)
			{
				minutes = minutes ++;
			}
		setMinutes(this.minutes);
			if (minutes == 0)
			{
				hours ++ ;
			}
		setHours(this.hours);
		return toString();
	}
}