/**
 * Tester class for Clock.
 *
 * @author George Thomas
 * @version 11/17/2016
 */
public class ClockTest
{
   public static void main(String [] args)
   {

        //Create some clocks and print their times
        Clock c1 = new Clock(-3,-21,-30);
        Clock c2,c3;
        System.out.println(c1);

        c1 = new Clock(24,60,60);
        System.out.println(c1);

        c1 = new Clock(3,21,30);
        System.out.println(c1);

        c2 = new Clock(3,21,30);
        c3 = new Clock(23,59,59);
        System.out.println(c1.equals(c2));
        System.out.println(c1.equals(c3));

        //Tick  clock twice and print its time
        c1.tick();
        c1.tick();
        c3.tick();
        System.out.println(c1);
        System.out.println(c3);

    }
}
