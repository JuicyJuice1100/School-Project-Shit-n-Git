
/**
 * 9/22/2016
 * Justin Espiritu
 * 
 * Number of chocolate bars a person should eat, based on no excersize, to maintain the same weight
 * 
 * Algorithm:
 *  Input: pounds, inches, and years
 *  Output: How many chocolate bars one should eat
 *  Assumptions:  All inputs will be in: pounds for weight, inches for height, years for age.  All outputs will be only for male or female.
 *  
 *  Steps:
 *      Input:
 *          -prompt user for weight in pounds
 *          -weight <- get input from user
 *          -prompt user for height in inches
 *          -height <- get input from user
 *          -prompt user for age in years
 *          -age <- get input from user
 *          
 *      Process:
 *          female calories <- 655 + (4.3 * weight) + (4.7 * height) - (4.7 * age)
 *          male calories <- 66 + (6.3 * weight) + (12.9 * height) - (6.8 * age)
 *          chocolate bars for female <- female calories / 230
 *          chocolate bars for male <- male calories / 230
 *          
 *     Output:
 *          Print out in chocolate bars female should eat and chocolate bars male should eat
 */
import java.util.Scanner;

public class Calories
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        double weight, height, age, femaleMeta, maleMeta, chocFemale, chocMale; // femaleMeta = female basic metabolic rate, maleMeta = male basic metabolic rate, chocFemale = how many chocolate bars a female should eat, chocMale = how many chocolate bars a male should eat
        
        //input
        System.out.print("Enter weight in pounds: ");
        weight = scan.nextDouble();
        System.out.print("Enter height in inches: ");
        height = scan.nextDouble();
        System.out.print("Enter age in years: ");
        age = scan.nextDouble();
        
        //process
        femaleMeta = 655 + 4.3 * weight + 4.7 * height - 4.7 * age;
        maleMeta = 66 + 6.3 * weight + 12.9 * height - 6.8 * age;
        chocFemale = femaleMeta / 230;
        chocMale = maleMeta / 230;
        
        //output
        System.out.println("If you're female you should eat " + chocFemale + " chocolate bars to maintain your weight.");
        System.out.println("If you're male you should eat " + chocMale + " chocolate bars to maintain your weight.");
    } // end main
} // end class Calories
        
        
 
        
        
        
    