
/**
 * Justin Espiritu
 * 11/10/16
 * 
 * Driver for class Triangle
 */
public class Driver
{
    public static void main(String[] args)
    {
        Triangle t1 = new Triangle(5, 4, 3);
        
        //Call accessors
        System.out.println(t1.getSideA());
        System.out.println(t1.getSideB());
        System.out.println(t1.getSideC());
        
        //Call mutators
        t1.setSideA(3);
        t1.setSideB(5);
        t1.setSideC(4);
        
        //Call other methods
        System.out.println(t1.getPerimeter());
        System.out.println(t1.area());
        System.out.println(t1.toString());
    }//end main
}//end class Driver