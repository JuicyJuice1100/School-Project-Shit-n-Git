
/**
 * Justin Espiritu
 * 11/10/16
 * 
 * Create the perameters to create a triangle
 */
public class Triangle
{
    private double sideA, sideB, sideC;
   
    public Triangle(double a, double b, double c)
    {
        sideA = a;
        sideB = b;
        sideC = c;
    }
    
    public double getSideA()
    {
        return sideA;
    }
    
    public double getSideB()
    {
        return sideB;
    }
    
    public double getSideC()
    {
        return sideC;
    }
    
    public void setSideA(double a)
    {
        sideA = a;
    }
    
    public void setSideB(double b)
    {
        sideB = b;
    }
    
    public void setSideC(double c)
    {
        sideC = c;
    }
    
    public double getPerimeter()
    {
        return sideA + sideB + sideC;
    }
    
    public double area()
    {
        double p;
        p = getPerimeter();
        p = p/2;
        
        return Math.sqrt(p * ((p - sideA) * (p - sideB) * (p - sideC)));
    }
    
    public boolean isRightAngled()
    {
        double hypotenuse;
        hypotenuse = 0;
        
        //finding the longest side of the triangle, hypotenuse
        
        if (sideA > sideB && sideA > sideC)
        {
            hypotenuse = sideA;
        }
        else if (sideB > sideA && sideB > sideC)
        {
            hypotenuse = sideB;
        }
        else 
        {
            hypotenuse = sideC;
        }
        
        //squaring as the formula uses hypotenuse squared
        hypotenuse = hypotenuse * hypotenuse;
        
        /*
         * finding out if triangle has a right angle using formula
         * a^2 + b^2 = c^2, c = hypotenuse, a and b = other 2 sides
         */
        
        if (hypotenuse ==  sideA * sideA + sideB * sideB ||
        hypotenuse == sideB * sideB + sideC * sideC ||
        hypotenuse == sideA * sideA + sideC * sideC)
        {
            return true;
        }
        return false;
    }
    
    public String toString()
    {
      return "Right-Angle: " + isRightAngled() + "\nArea: " + area() + "\nperimeter: "
      + getPerimeter() + "\nLength of sides: " + sideA + ", " + sideB + ", " + sideC;
    }
}//end class Triangle
    