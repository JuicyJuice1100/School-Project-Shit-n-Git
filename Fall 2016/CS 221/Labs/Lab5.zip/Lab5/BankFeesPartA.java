
/**
 * Justin Espiritu
 * 10/13/16
 * 
 * Program will ask user number of checks written for the month and program will calculate and display
 * the bank's service fees for the month.  (Must use if-else-if with complex conditions)
 */
import java.util.Scanner;

public class BankFeesPartA
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        int checks; 
        double fee;
        System.out.println("Enter how many checks written this month");
        checks = scan.nextInt();
        
        if (checks < 0)
        {
            System.out.println("Can't have negative amount of checks");
        }
        else if (checks < 20)
        {
            fee = checks * .10;
            System.out.println("Fee for the month = $" + fee);
        }
        else if (checks >= 20 && checks < 40)
        {
            fee = checks * .08;
            System.out.println("Fee for the month = $" + fee);
        }
        else if (checks >= 40 && checks < 60)
        {
            fee = checks * .06;
            System.out.println("Fee for the month = $" + fee);
        }
        else 
        {
            fee = checks * .04;
            System.out.println("Fee for the month = $" + fee);
        }
    }//end main
}//end class BankFeesPartA