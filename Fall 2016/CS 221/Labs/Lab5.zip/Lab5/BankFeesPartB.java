
/**
 * Justin Espiritu
 * 10/13/16
 * 
 * Program will ask user number of checks written for the month and program will calculate and display
 * the bank's service fees for the month.  (Must use Switch)
 */
import java.util.Scanner;

public class BankFeesPartB
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        int checks; 
        double fee;
        System.out.println("Enter how many checks written this month");
        checks = scan.nextInt();
        
        if (checks < 0)
        {
            System.out.println("Cannot have negative checks");
            System.exit(0);
        }
        switch (checks/10)
        {
            case 0: case 1: fee = checks * .10;
            System.out.println("Fees for the month = to $ " + fee);
            break;
            case 2: case 3: fee = checks * .08;
            System.out.println("Fees for the month = to $ " + fee);
            break;
            case 4: case 5: fee = checks * .06;
            System.out.println("Fees for the month = to $ " + fee);
            break;
            default: fee = checks * .04;
            System.out.println("Fees for the month = to $ " + fee);
        }
    }//end main
}//end class BankFeesPartB