
/**
 * No programing languaging backround.  Have background using Microsoft office programs
 * and tournament organizer programs such as challonge,tournament Mango, and TIO.
 * 
 * @author (Justin Espiritu) 
 * @version (9/8/2016)
 */
public class FirstLab {
    public static void main(String[] args) {
        System.out.println("Hello World! This is my first program!");
        System.out.println("Java seems to be fun");
    }
}
