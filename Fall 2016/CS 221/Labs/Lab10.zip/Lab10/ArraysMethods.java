/*
Justin Espiritu
12/1/16

Create a program that checks if two array's sums are equal 
*/

public class ArraysMethods
{
	//comparing the sum of two arrays
	public static boolean arraySum(int[] arrayOne, int[] arrayTwo)
	{
		int sumOfArrayOne = 0;
		int sumOfArrayTwo = 0;

		//adding all integers in arrayOne
		for(int counter = 0; counter < arrayOne.length; counter++)
		{
			sumOfArrayOne += arrayOne[counter];
		}

		//adding all integers in arrayTwo
		for(int counter = 0; counter < arrayTwo.length; counter++)
		{
			sumOfArrayTwo += arrayTwo[counter];
		}

		//compare sums and return boolean
		if(sumOfArrayOne == sumOfArrayTwo)
		{
			return true;
		}
		return false;
	}

	//see how many times an integer occurs in array
	public static int arrayRepeat(int[] array, int num)
	{
		int howMany = 0;

		for(int counter = 0; counter < array.length; counter++)
		{
			if(array[counter] == num)
			{
				howMany++;
			}
		}

		return howMany;
	}

}