/*
Justin Espiritu
12/1/2016

Driver class to test ArrayMethods
*/

public class Driver
{
    public static void main(String[] args)
    {
       int[] arrayOne = {1, 2, 5, 7};
       int[] arrayTwo = {10, 5};
       int numSearch = 5;

       boolean output = ArraysMethods.arraySum(arrayOne, arrayTwo);
       int result = ArraysMethods.arrayRepeat(arrayOne, numSearch);
       System.out.println("Are the arrays' sums equal: " + output);
       System.out.println("How many times does integer appear: " + result);
    }
}