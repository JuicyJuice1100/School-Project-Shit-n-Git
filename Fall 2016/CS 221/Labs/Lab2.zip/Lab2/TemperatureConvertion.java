
/**
 * converts fehrneheit to celsius
 * 
 * Justin Espiritu
 * 9/15/16
 */
import java.util.Scanner;

public class TemperatureConvertion
{
   public static void main(String[] args)
   {
       Scanner scan = new Scanner(System.in);
       double fahrenheit, celsius;
       
       System.out.println("enter degrees in fahrenheit:");
       //input
       fahrenheit = scan.nextDouble(); 
       
       //processing 
       celsius = (((fahrenheit - 32)*5)/9); 
       
       //output
       System.out.println("Conversion in celsius = " + celsius); 
    } //end main
} //end class TemperatureConvertion
