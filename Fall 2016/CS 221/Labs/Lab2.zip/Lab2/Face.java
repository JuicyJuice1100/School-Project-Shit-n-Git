
/**
 * Program creates a face
 * 
 * Justin Espiritu
 * 9/15/16
 */
public class Face
{
   public static void main(String[] args)
   {
       // input
       // process
       // output
       System.out.print("    /////    ");
       System.out.println("   |     |    ");
       System.out.println("   | > < |    ");
       System.out.println("  \\|     |/   ");
       System.out.println("   | (^) |    ");
       System.out.println("   -------    ");
    } //end main
} // end class Face
