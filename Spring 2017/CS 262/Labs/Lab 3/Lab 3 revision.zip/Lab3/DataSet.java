/*
@Justin Espiritu
@Version 1
George Georgiev
Lab 2
#Class will alow the user to input a data set of integers and get the minimum, maximum, and average
##Data in dataSet equal to 0 means NULL
*/
import java.util.Arrays;

public class DataSet
{
    private int[] dataSet ;
    private int count ;

    //constructor that specifies the maximum number of items
    public DataSet(int max)
    {
        dataSet = new int[max];
        count = 0 ;
    }

    //default constor that creates a Dataset capable of handling 100 items
    public DataSet()
    {
        this(100);
    }

    public int getMin()
    {
        //set the min value to the largest possible int
        int min = Integer.MAX_VALUE;

        //go through each element in the dataSet and fine the smallest value
        for(i = 0; i < count && dataSet[i] != 0; i++)
        {   
            if(dataSet[i] < min)
            {
                min = dataSet[i];
            }
        }
        return min;
    }

    public int getMax()
    {
        //set the max value to the smallest possible int 
        int max = Integer.MIN_VALUE;

        //go through each element in the dataSet and find the largest value
        for(i = 0; i < count && dataSet[i] != 0; i ++)
        {
            if(dataSet[i] > max)
            {
                max = dataSet[i];
            }
        }
        return max;
    }

    public double getAvg()
    {
        double sum = 0, i;

        //go through each element in the dataSet to get the sum of all elements
        for(i = 0; i < count && dataSet[i] != 0; i++)
        {
            sum += dataSet[i];
        }
        //get the average by dividing sum by amount of elements not equal to 0
        return sum/i;
    }

    public void addDatem(int item)
    {   
        int index = 0;
        
        /*
        for(i = 0; i < dataSet.length; i++)
        {
            System.out.print(dataSet[i]);
        }
        System.out.println();
        */

        if(isFull() == true)
        {
            //create a new data set to copy old data set
            newDataSet = new int[dataSet.length * 2];
            //add new element to newDataSet asthe last element
            //newDataSet[newDataSet.length - 1] = item;
        }
        else
        {
            //create a new data set to copy old data set
            newDataSet = new int[dataSet.length];
        }

        /*
        copy old dataSet to newDataSet
        only i until the length of the old dataSet because we add new item above 
        if isFull() is true otherwise length of old and new dataSet are the same
        */
        
        //System.out.println(newDataSet[index]);

        while(dataSet[index] != 0 && index < dataSet.length)
        {
            index++;
        }

        //System.out.println(index);

        //add new data to new array
        newDataSet[index] = item;
        count = index + 1;

        //copy array elements to new array
        for(i = index - 1; i >= 0; i--)
        {
            newDataSet[i] = dataSet[i];
        }

        /*
        for(i = 0; i < dataSet.length - 1; i++)
        {
            //copy dataSet to new DataSet
            newDataSet[i] = dataSet[i];
        }
        */
        
        /*
        for(i = 0; i < newDataSet.length; i++)
        {
            System.out.print(newDataSet[i]);
        }
        System.out.println();
        */

        /*
        //add new element to newDataSet
        newDataSet[newDataSet.length - 1] = item;
        */
        dataSet = newDataSet;
        
        /*
        for(i = 0; i < dataSet.length; i++)
        {
            System.out.print(dataSet[i]);
        }
        System.out.println();
        */
    }

    public double standardDev()
    {
        double avg = getAvg(); 
        double sum = 0;
        double elemMinusMean;

        //find the summation of the dataSet
        for(i = 0; i < count; i++)
        {   
            elemMinusMean = Math.pow(dataSet[i] - avg, 2);
            sum += elemMinusMean;
        }

        //divide the summation by the amount of elements
        sum /= dataSet.length;

        //return the standard dev
        return Math.sqrt(sum);
       }

    public boolean isEmpty()
    {
        boolean isTrue = true;

        //go through each element in dataSet to see if array is empty
        for(i = 0; i < dataSet.length -1; i++)
        {
            if(dataSet[i] != 0)
            {
                isTrue = false;
                break;
            }
        }
        return isTrue;
    }

    public boolean isFull()
    {
        boolean isTrue = true;

        //go through each element in dataSet to see if array is full
        for(i = 0; i < dataSet.length - 1; i++)
        {
            if(dataSet[i] == 0)
            {
                isTrue = false;
                break;
            }
        }
        return isTrue;
    }

    public void deleteItemAt(int index)
    {   
        //create new dataSet to copy dataSet without the index

        //copy elements starting from index to newDataSet
        for(i = index; i < dataSet.length - 1; i++)
        {
            dataSet[i] = dataSet[i + 1];
        }

        count--;
    }


    public String display()
    {
        //create new dataSet to copy old dataSet without 0's
        
        return Arrays.toString(dataSet);
    }

    public void clear()
    {
        newDataSet = new int[dataSet.length];
        dataSet = Arrays.copyOfRange(newDataSet, 0, dataSet.length - 1);

        //must reset count to 0 so we know where we are in the array
        count = 0;
    }

    public void insert(int item, int index)
    {
        if(isFull() == true)
        {
            newDataSet = new int[dataSet.length + 1];
        }
        else
        {
        //create new dataSet to copy dataSet without the index
        newDataSet = new int[dataSet.length];
        }

        //insert new item to index
        newDataSet[index] = item;

        //copy elements before index to newDataSet
        for(i = index - 1; i >= 0; i--)
        {
            newDataSet[i] = dataSet[i];
        }

        //copy elements after index to newDataSet
        for(i = index + 1; i < dataSet.length; i++)
        {
            newDataSet[i] = dataSet[i - 1];
        }

        //set newDataSet to dataSet
        dataSet = newDataSet;

        //update count
        count++;
    }
}