// Fig. 10.8: BasePlusCommissionEmployee.java
// BasePlusCommissionEmployee class extends CommissionEmployee.

public class BasePlusCommissionEmployee extends CommissionEmployee 
{
    private double baseSalary;
    
    public BasePlusCommissionEmployee(String firstName, String lastName, String socialSecurityNumber, double grossSales, double commissionRate, double baseSalary){
        super(firstName, lastName, socialSecurtyNumber, grossSales, commissionRate);
        if (baseSalary < 0.0)
        throw new IllegalArgumentException(
            "Base salary must be >= 0.0");

        this.baseSalary = baseSalary;
    }

    public double earnings(){
        return getCommissionRate() * getGrossSales() + baseSalary;
    } 

    public double getBaseSalary(){
        return baseSalary;
    }

    @Override
    public String toString(){
        return String.format("base salaried commission employee: %s\n
        %s: %d",
        super.toString(), "base salary", getBaseSalary());
    }
    
    
    
} // end class BasePlusCommissionEmployee


