// Fig. 10.6: HourlyEmployee.java
// HourlyEmployee class extends Employee.

public class HourlyEmployee extends Employee 
{
    private double wage;
    private double hours;

    public HourlyEmployee(String firstName, String lastName, String socialSecurityNumber, double wage, double hours){
        super(firstName, lastName, socialSecurityNumber);

        if (wage < 0.0)
            throw new IllegalArgumentException(
            "Wage must be >= 0.0");)
        this.wage = wage;
        this.hours = hours;
    }

    public double earnings(){
        double pay;
        if(hours <= 40){
            pay = wage * hours;
        }
        else{
            pay = 40 * wage + (hours - 40) * wage * 1.5;
        }
        return pay;
    } 

    public double getWage(){
        return wage;
    }

    public double getHours(){
        return hours;
    }

    @Override
    public String toString(){
        return String.format("Hourly employee: %s\n
        %s: %d; %s: %d\n",
        super.toString(), "hourly wage", getWage()), "hours worked", getHours());
    }
    
    
} // end class HourlyEmployee


