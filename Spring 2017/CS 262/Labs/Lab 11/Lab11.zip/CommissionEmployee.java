// Fig. 10.7: CommissionEmployee.java
// CommissionEmployee class extends Employee.

public class CommissionEmployee extends Employee 
{
   public double grossSales;
   public double commissionRate;

   public CommissionEmployee(String firstName, String lastName, String socialSecurityNumber, double grossSales, double commissionRate){
       super(firstName, lastName, socialSecurtyNumber);

       if (commissionRate < 0.0)
            throw new IllegalArgumentException(
            "Commission rate must be >= 0.0");)
       this.grossSales = grossSales;
       this.commissionRate = commissionRate;
   }

   public double earnings(){
        return commissionRate * grossSales;
   } 

   public double getGrossSales(){
       return grossSales;
   }

   public double getCommissionRate(){
       return commissionRate;
   }

   @Override
   public String toString(){
        return String.format("Commission employee: %s\n
        %s: %d\n %s: %d\n",
        super.toString(), "gross sales", getGrossSales(), "commission rate", getCommissionRate());
   }
    
    
} // end class CommissionEmployee

