/*
Justin Espiritu
Version
#Test creating a drawing
*/

import javax.swing.JFrame;

public class DrawRainbowJawBreakerTest
{
	public static void main(String[] args)
	{
		DrawRainbowJawBreaker panel = new DrawRainbowJawBreaker();
		JFrame application = new JFrame();

		application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		application.add(panel);
		application.setSize(400, 400);
		application.setVisible(true);
	}
}