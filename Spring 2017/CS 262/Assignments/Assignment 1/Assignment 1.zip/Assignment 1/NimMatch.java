/*
Justin Espiritu
CSC 262 OO Design & Programming II
Assignement 1: The Game of Nim
The game of "Nim" is played with two players.  A game begins with 15 sticks laid out in a row.  
Players take turns removing sticks.  On your turn you must remove either one, two, or three sticks. 
The player who removes the last stick is the loser.
Versions 1.0
*/
import java.util.Scanner;

public class NimMatch
{	
	private int humanScore = 0, computerScore = 0, gameNumber;

	private Scanner scan = new Scanner(System.in);

	public void playMatch(int mode)
	{
		int playAgain = 0;
		do
		{	
			//create NimGame object
			NimGame game = new NimGame();

			//play game, update, and report scores
			game.playGame(gameNumber%2 + 1, mode);

			gameNumber++;

			updateScore(game);
			System.out.println(reportScores());
			
			//Ask user if they would like to play again and grab inpu 1 = play again anything else = exit
			System.out.println("Would you like to play again? (1 = play again, 2 = exit)");
			playAgain = scan.nextInt();

		}while(playAgain == 1);
	}

	public void updateScore(NimGame game)
	{
		if(game.userWon() == true)
		{
			humanScore ++;
		}
		else
		{
			computerScore ++;
		}
	}

	public String reportScores()
	{	
		return "Player = " + humanScore + " Computer = " + computerScore;
	}
}