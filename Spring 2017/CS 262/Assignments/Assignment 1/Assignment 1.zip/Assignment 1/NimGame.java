/*
@Justin Espiritu
CSC 262 OO Design & Programming II
Assignement 1: The Game of Nim
#The game of "Nim" is played with two players.  A game begins with 15 sticks laid out in a row.  
Players take turns removing sticks.  On your turn you must remove either one, two, or three sticks. 
The player who removes the last stick is the loser.
#NimGame class plays 1 game of NimGame
@Versions 1.1
*/
import java.util.Scanner;

public class NimGame
{
	//HUMAN = 1, COMPUTER = 2;
	private int turn, winner, mode;

	NumOfSticks sticks = new NumOfSticks();
	Scanner scan = new Scanner(System.in);

	public void playGame(int turn, int mode)
	{	
		this.turn = turn;
		this.mode = mode;
		int sticks;
		
		//alternate turns between computer and human until game is finished
		do
		{	
			//show current amount of sticks
			System.out.println(this.sticks.stickGraphic() + " " + this.sticks.getSticks());

			if(this.turn == 1)
			{
				System.out.println("How many sticks would you like to take?");
				sticks = scan.nextInt();
				
				if(humanMove(sticks) == true)
				{
					//make sure that each turn through loop alternates player/computer's turn
					this.turn++;
					this.sticks.setSticks(this.sticks.getSticks() - sticks);
				}
				else
				{
					System.out.println("invalid number.  Please enter a number between 1 and 3");
				}
			}
			else
			{	
				//play against random computer
				if(this.mode == 1)
				{
					computerMove();
					this.turn--;
					System.out.println("Computer Moves");
				}
				else
				{
					computerMoveWin();
					this.turn--;
					System.out.println("Computer Moves");
				}
			}

		//Greater than 1 who ever grabs the last stick loses	
		}while(this.sticks.getSticks() > 1);
		
		//display who won the game
		if(userWon() == true)
		{
			System.out.println("You Win");
		}
		else
		{
			System.out.println("You Lose");
		}
	}

	//player's move
	public boolean humanMove(int move)
	{
		if(move < 1 || move > 3 || move > sticks.getSticks())
		{
			return false;
		}
		return true;
	}

	//Random Computer
	public void computerMove()
	{
		int move = 1 + (int)(Math.random() * 3);
		if(sticks.getSticks() < 3)
		{
			move = 1 + (int)(Math.random() * sticks.getSticks());
		}
		sticks.setSticks(sticks.getSticks() - move); 
	}

	//Winner Strategy Computer
	public void computerMoveWin()
	{
		int move = sticks.getSticks();

		do
		{
			move--;
		}while(move%4 > 0);
		
		if(sticks.getSticks() == move + 1)
		{
			computerMove();
		}
		else
		{
			sticks.setSticks(move + 1);
		}
	}

	public boolean userWon()
	{
		if(turn == 1)
		{
			return false;
		}
		return true;
	}

	public int getMode()
	{
		return mode;
	}

	public void setMode(int mode)
	{
		this.mode = mode;
	}
}