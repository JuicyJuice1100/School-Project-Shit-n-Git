/*
@Justin Espiritu
CSC 262 OO Design & Programming II
Assignement 1: The Game of Nim
#The game of "Nim" is played with two players.  A game begins with 15 sticks laid out in a row.  
Players take turns removing sticks.  On your turn you must remove either one, two, or three sticks. 
The player who removes the last stick is the loser.
#Driver for the to test NimGame and NimMatch class
## note:  This test both NimGame and NimMatch serperately.
@Versions 1.1
*/

import java.util.Scanner;

public class Driver
{
	public static void main(String[] args)
	{
		int turn, mode;

		Scanner scan = new Scanner(System.in);
		
		NimGame game = new NimGame();
		NimMatch match = new NimMatch();

		System.out.println("Would you like to go first or let the computer start? (1 = Player, 2 = Computer)");
		turn = scan.nextInt();
		
		//Ask again if invalid input
		if(turn < 1 || turn > 2)
		{
			//repeat until given a valid input
			do
			{
				System.out.println("Please enter a valid input.  (1 = Player, 2 = Computer)");
				turn = scan.nextInt();
			}while(turn < 1 || turn > 2);
		}

		System.out.println("What computer would you like to play against?  (1 = Random Computer, 2 = Winning Strategy Computer)");
		mode = scan.nextInt();

		//Ask again if invalid input
		if(mode < 1 || mode > 2)
		{
			//repeat until given a valid input
			do
			{
			System.out.println("Please enter a valid input. (1 = Random Computer, 2 = Winning Strategy Computer)");
			mode = scan.nextInt();
			}while(mode < 1 || mode > 2);
		}
		
		game.playGame(turn, mode);
		//As noted before this test both NimGame and NimMatch seperately
		//You will play match starting at 0 | 0 and against computer selected above
		match.playMatch(mode);
	}
}