// Justin Espiritu, CalvinMeier
// 4/27/2017
// AlarmClock class that extends WorldTime


public class AlarmClock extends WorldTime{
    private int alarmHours;
    private int alarmMinutes;
    private int alarmSeconds;
    private boolean alarmOn;
    private Thread alarmThread;
    private ClockGUIAlarm alarm;

    public AlarmClock(){
        super();
        alarmHours = 0;
        alarmMinutes = 0;
        alarmSeconds = 0;
        alarmOn = false;

        alarm = new ClockGUIAlarm();
        alarmThread = new Thread(alarm);
        alarmThread.start();
    }

    public void alarmRing(){
        SoundClipTest alarmRing = new SoundClipTest();
    }

    public boolean getAlarmOn(){
       return alarmOn; 
    }

    public void setAlarmOn(boolean alarmOn){
        this.alarmOn = alarmOn;
    }

    public long alarmTotalSeconds(){
        long totalSeconds = 0;

        totalSeconds += alarmHours * 3600;
        totalSeconds += alarmMinutes * 60;
        totalSeconds += alarmSeconds;

        return totalSeconds;
    }

    public void setAlarmHours(int hours){
        alarmHours = hours;
    }

    public void setAlarmMinutes(int minutes){
        alarmMinutes = minutes;
    }

    public void setAlarmSeconds(int seconds){
        alarmSeconds = seconds;
    }

    public int getAlarmHours(){
        return alarmHours;
    }

    public int getAlarmMinutes(){
        return alarmMinutes;
    }

    public int getAlarmSeconds(){
        return alarmSeconds;
    }
}