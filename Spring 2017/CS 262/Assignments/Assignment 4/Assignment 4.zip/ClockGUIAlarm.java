import java.awt.*;
import java.awt.event.*;
import javax.swing.* ;

public class ClockGUIAlarm extends JPanel implements Runnable{
    private JPanel setAlarmPanel;
    private JPanel setSoundPanel;
    private JPanel exitPanel;
    private JButton setAlarmButton;
    private JButton backButton;
    private JTextField setAlarmText;
    // private JTextField alarmtext;
    // private JTextField soundText;
    private JRadioButton dogSounds;
    private JRadioButton donkeySounds;
    private JRadioButton duckSounds;
    private JRadioButton alarmOn;
    private JRadioButton alarmOff;

    public ClockGUIAlarm(){
        super();
        setLayout(new BorderLayout());

        //alarm panel items
        setAlarmPanel = new JPanel();
        setAlarmPanel.setLayout(new FlowLayout());
        setAlarmPanel.setSize(30,30);
        setAlarmText = new JTextField(10);

        alarmOn = new JRadioButton("Alarm On");
        alarmOff = new JRadioButton("Alarm Off");

        ButtonGroup alarm = new ButtonGroup();
        alarm.add(alarmOn);
        alarm.add(alarmOff);

        setAlarmPanel.add(setAlarmText);
        setAlarmPanel.add(alarmOn);
        setAlarmPanel.add(alarmOff);
        add(setAlarmPanel, BorderLayout.NORTH);

        //sound panel items
        setSoundPanel = new JPanel();
        setSoundPanel.setLayout(new FlowLayout());
        setSoundPanel.setSize(20,20);

        dogSounds = new JRadioButton("Dog Sounds");
        donkeySounds = new JRadioButton("Donkey Sounds");
        duckSounds = new JRadioButton("Duck Sounds");

        ButtonGroup sounds = new ButtonGroup();
        sounds.add(dogSounds);
        sounds.add(donkeySounds);
        sounds.add(duckSounds);

        setSoundPanel.add(dogSounds);
        setSoundPanel.add(donkeySounds);
        setSoundPanel.add(duckSounds);
        add(setSoundPanel, BorderLayout.CENTER);

        //exit panel items
        exitPanel = new JPanel();
        exitPanel.setLayout(new FlowLayout());
        add(exitPanel, BorderLayout.SOUTH);

        setAlarmButton = new JButton("Set Alarm");
        backButton = new JButton("Back");
        exitPanel.add(backButton);
        exitPanel.add(setAlarmButton);

        //handlers
        EventHandler handler = new EventHandler() ;
        alarmOn.addActionListener(handler) ;
        alarmOff.addActionListener(handler) ;
        dogSounds.addActionListener(handler) ;
        donkeySounds.addActionListener(handler) ;
        duckSounds.addActionListener(handler) ;
        backButton.addActionListener(handler) ;
        setAlarmButton.addActionListener(handler) ;
    }

    @Override
    public void run(){

    }

    private class EventHandler implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e){
            if(e.getSource() == alarmOn){

            }
            else if(e.getSource() == alarmOff){

            }
            else if(e.getSource() == dogSounds){

            }
            else if(e.getSource() == donkeySounds){

            }
            else if(e.getSource() == duckSounds){

            }
            else if(e.getSource() == backButton){
                removeAll();
            }
            else if(e.getSource() == setAlarmButton){

            }
        }
    }
}