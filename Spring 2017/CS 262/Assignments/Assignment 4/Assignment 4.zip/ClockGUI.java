
/**
 * ClockGUI w/ ClockAlarmGUI subclass
 * 
 * @author Justin Espiritu, Calvin Meier
 * @version 4/27/2017
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.* ;


public class ClockGUI extends JPanel implements Runnable
{
   private static final int MILISECONDS_TO_SECONDS = 1000 ;
    
   //private WorldTime worldTime ;
   private JTextField txtTime ;
   private JPanel panelTimeZone ;
   private JButton btnSetTimeZone ;
   private JTextField txtSetTimeZone ;
   private AnalogClock analogPanel ; 
   private ClockGUIAlarm alarmPanel;
//    private JPanel alarmPanel;
   private JButton alarmButton;
//    private JButton backButton;
   private AlarmClock alarmClock;

   
   public ClockGUI()
   {
       super() ;
       setLayout(new BorderLayout()) ;
       
       alarmClock = new AlarmClock() ;
       
       txtTime = new JTextField(20) ;
       txtTime.setEditable(false) ;
       add(txtTime, BorderLayout.NORTH) ;
       
       panelTimeZone = new JPanel() ;
       btnSetTimeZone = new JButton("Set Time Zone") ;
       txtSetTimeZone = new JTextField(6) ;
       panelTimeZone.add(btnSetTimeZone) ;
       panelTimeZone.add(txtSetTimeZone) ;
       add(panelTimeZone, BorderLayout.SOUTH) ;
       
       analogPanel = new AnalogClock(alarmClock) ;
       analogPanel.setSize(50, 50) ;
       add(analogPanel, BorderLayout.CENTER) ;

       alarmButton = new JButton("Set Alarm");
       panelTimeZone.add(alarmButton);
    //    panelTimeZone.add(alarmButton);
    //    alarmPanel = new JPanel();
    //    alarmPanel.setSize(50,50);
    //    alarmPanel.setLayout(new BorderLayout());

    //    backButton = new JButton("Back");

        alarmPanel = new ClockGUIAlarm();

       
       
       
       
       EventHandler handler = new EventHandler() ;
       btnSetTimeZone.addActionListener(handler) ;
       alarmButton.addActionListener(handler);
    //    backButton.addActionListener(handler);
    }
    
    // public void alarmPanel()
    // {
    //     add(alarmPanel, BorderLayout.CENTER);
    //     alarmPanel.add(backButton, BorderLayout.SOUTH);

    // }
    
    
    @Override
    public void run()
    {
        while(true)
        {
            txtTime.setText(alarmClock.toString()) ;
            
            repaint() ;
        
            try {
        
                  Thread.sleep(MILISECONDS_TO_SECONDS);
        
              } catch (InterruptedException ex) {}
        
        }
 
    }
    
    private class EventHandler implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            int timeZone = 0;
            int alarmHours = 0;
            int alarmMinutes = 0;
            int alarmSeconds = 0;

            boolean valid = true ;
            
            if(e.getSource() == btnSetTimeZone)
            {
                try
                {
                    timeZone = Integer.parseInt(txtSetTimeZone.getText());
                }
                catch (Exception ex)
                {
                    valid = false ;
                }
                
                if(valid)
                {
                    alarmClock.setTimeZone(timeZone)  ;
                }
            }
            else if(e.getSource() == alarmButton)
            {
                remove(analogPanel);
                add(alarmPanel);
                validate();
                repaint();
            }
            else if(e.getSource() == alarmPanel.backButton)
            {
                remove(alarmPanel);
                add(analogPanel, BorderLayout.CENTER);
                validate();
                repaint();
            }
            else if(e.getSource() == alarmPanel.alarmOn){
                alarmClock.setAlarmOn(true);
            }
            else if(e.getSource() == alarmPanel.alarmOff){
                alarmClock.setAlarmOn(false);
            }
            // else if(e.getSource() == alarmPanel.dogSounds){
            //     //set to dog sounds
            // }
            // else if(e.getSource() == alarmPanel.donkeySounds){
            //     //set to donkey sounds
            // }
            // else if(e.getSource() == alarmPanel.duckSounds){
            //     //set to duck sounds
            // }
            else if(e.getSource() == alarmPanel.setAlarmButton){
                try
                {
                    alarmHours = Integer.parseInt(alarmPanel.setAlarmHours.getText());
                    alarmMinutes = Integer.parseInt(alarmPanel.setAlarmMinutes.getText());
                    alarmSeconds = Integer.parseInt(alarmPanel.setAlarmSeconds.getText());
                }
                catch (Exception ex)
                {
                    valid = false ;
                }
                
                if(valid)
                {
                    alarmClock.setAlarmHours(alarmHours);
                    alarmClock.setAlarmMinutes(alarmMinutes);
                    alarmClock.setAlarmSeconds(alarmSeconds);
                    remove(alarmPanel);
                    add(analogPanel, BorderLayout.CENTER);
                    validate();
                    repaint();
                }
            }
          
        }
    } // end EventHandler

        public class ClockGUIAlarm extends JPanel implements Runnable{
        private JPanel setAlarmPanel;
        private JPanel setSoundPanel;
        private JPanel exitPanel;
        private JButton setAlarmButton;
        private JButton backButton;
        private JTextField setAlarmHours;
        private JTextField setAlarmMinutes;
        private JTextField setAlarmSeconds;
        private JRadioButton dogSounds;
        private JRadioButton donkeySounds;
        private JRadioButton duckSounds;
        private JRadioButton alarmOn;
        private JRadioButton alarmOff;

        public ClockGUIAlarm(){
            super();
            setLayout(new BorderLayout());

            //alarm panel items
            setAlarmPanel = new JPanel();
            setAlarmPanel.setLayout(new FlowLayout());
            setAlarmPanel.setSize(30,30);
            setAlarmHours = new JTextField(2);
            setAlarmMinutes = new JTextField(2);
            setAlarmSeconds = new JTextField(2);

            alarmOn = new JRadioButton("Alarm On");
            alarmOff = new JRadioButton("Alarm Off");

            ButtonGroup alarm = new ButtonGroup();
            alarm.add(alarmOn);
            alarm.add(alarmOff);

            setAlarmPanel.add(setAlarmHours);
            setAlarmPanel.add(setAlarmMinutes);
            setAlarmPanel.add(setAlarmSeconds);

            setAlarmPanel.add(alarmOn);
            setAlarmPanel.add(alarmOff);
            add(setAlarmPanel, BorderLayout.NORTH);

            //sound panel items
            setSoundPanel = new JPanel();
            setSoundPanel.setLayout(new FlowLayout());
            setSoundPanel.setSize(20,20);

            dogSounds = new JRadioButton("Dog Sounds");
            donkeySounds = new JRadioButton("Donkey Sounds");
            duckSounds = new JRadioButton("Duck Sounds");

            ButtonGroup sounds = new ButtonGroup();
            sounds.add(dogSounds);
            sounds.add(donkeySounds);
            sounds.add(duckSounds);

            setSoundPanel.add(dogSounds);
            setSoundPanel.add(donkeySounds);
            setSoundPanel.add(duckSounds);
            add(setSoundPanel, BorderLayout.CENTER);

            //exit panel items
            exitPanel = new JPanel();
            exitPanel.setLayout(new FlowLayout());
            add(exitPanel, BorderLayout.SOUTH);

            setAlarmButton = new JButton("Set Alarm");
            backButton = new JButton("Back");
            exitPanel.add(backButton);
            exitPanel.add(setAlarmButton);

            //handlers
            EventHandler handler = new EventHandler() ;
            alarmOn.addActionListener(handler) ;
            alarmOff.addActionListener(handler) ;
            dogSounds.addActionListener(handler) ;
            donkeySounds.addActionListener(handler) ;
            duckSounds.addActionListener(handler) ;
            backButton.addActionListener(handler) ;
            setAlarmButton.addActionListener(handler) ;
        }

        @Override
        public void run(){
            while(true){
                if(alarmClock.getAlarmOn()){
                     alarmClock.alarmRing();
                }
            }
        }


    }
}
