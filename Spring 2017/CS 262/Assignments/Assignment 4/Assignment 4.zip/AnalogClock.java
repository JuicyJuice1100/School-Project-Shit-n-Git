
/**
 * Creates resizable analog clocks
 * 
 * @author Justin Espiritu, Calvin Meier
 * @version 4/27/17
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.* ;

public class AnalogClock extends JPanel 
{
//    private WorldTime worldTime ;
    private AlarmClock alarmClock;
   public AnalogClock(AlarmClock worldTime)
   {
       alarmClock = worldTime ;
    }
   
   
        @Override
     public void paintComponent(Graphics g) 
     {
        double minsecdeg = (double)Math.PI / 30;
        double hrdeg = (double)Math.PI / 6 ;
        int tx, ty ;
        int xpoints[] = new int[3];
        int ypoints[] = new int[3]; 
         
         
        g.setColor(Color.gray);
        g.fillRect(0, 0, getWidth(), getHeight());
        g.setColor(Color.ORANGE);
        g.fillOval(5, 5,getWidth()-20, getWidth()-20);
        g.setColor(Color.BLUE);
        g.fillOval(10, 10, getWidth() - 30, getWidth()-30);
        g.setColor(Color.ORANGE);
        g.fillOval((getWidth()-20)/2,(getWidth()-20)/2,15,15);
        g.setFont(g.getFont().deriveFont(Font.BOLD,32));

         //for(int i=1 ; i<=12 ; i++)
           //g.drawString(Integer.toString(i),((getWidth())/2)+(i/12)*11+(int)(((getWidth())/2)*Math.sin(i*Math.PI/6)),((getWidth())/2)-(int)(((getWidth())/2)*Math.cos(i*Math.PI/6)));


 
       //second hand
        tx = getWidth()/2 + (int)((getWidth()-30)/2 * Math.sin(alarmClock.getSeconds() * minsecdeg));
        ty = getWidth()/2 - (int)((getWidth()-30)/2 * Math.cos(alarmClock.getSeconds() * minsecdeg));
        g.drawLine(getWidth()/2, getWidth()/2 , tx, ty);

        //minute hand
        tx = getWidth()/2 + (int)((getWidth() - 50)/2 * Math.sin(alarmClock.getMinutes() * minsecdeg));
        ty = getWidth()/2 - (int)((getWidth() - 50)/2 * Math.cos(alarmClock.getMinutes() * minsecdeg));
        xpoints[0] = getWidth()/2;
        xpoints[1] = tx + 5 ;
        xpoints[2] = tx - 5 ;
        ypoints[0] = getWidth()/2;
        ypoints[1] = ty + 5 ;
        ypoints[2] = ty - 5 ;
        g.fillPolygon(xpoints, ypoints, 3) ;

        //hour hand
        tx = getWidth()/2 + (int)((getWidth() - 100)/2 * Math.sin(alarmClock.getHours() % 12 * hrdeg + alarmClock.getMinutes() * Math.PI / 360));
        ty = getWidth()/2 - (int)((getWidth() - 100)/2 * Math.cos(alarmClock.getHours() % 12 * hrdeg + alarmClock.getMinutes() * Math.PI / 360));
        xpoints[1] = tx + 10 ;
        xpoints[2] = tx - 10;
        ypoints[1] = ty - 10;
        ypoints[2] = ty + 10;
        g.fillPolygon(xpoints, ypoints, 3);

        //alarm hand
        tx = getWidth()/2 + (int)((getWidth() - 100)/2 * Math.sin(alarmClock.getAlarmHours() % 12 * hrdeg + alarmClock.getAlarmMinutes() * Math.PI / 360));
        ty = getWidth()/2 - (int)((getWidth() - 100)/2 * Math.cos(alarmClock.getAlarmHours() % 12 * hrdeg + alarmClock.getAlarmMinutes() * Math.PI / 360));
        g.setColor(Color.RED);
        g.drawLine(getWidth()/2, getWidth()/2, tx, ty);
    }  // emd paintComponent()
}
