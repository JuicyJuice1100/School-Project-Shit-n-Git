
/**
 * Makes alarm sound till JFrame is closed
 * 
 * @author Justin Espiritu, Calvin Meier
 * @version 4/27/2017
 */
import java.net.URL;
import javax.sound.sampled.*;
import javax.swing.*;
import java.io.* ;

// To play sound using Clip, the process need to be alive.
// Hence, we use a Swing application.
public class SoundClipTest extends JFrame {

   public SoundClipTest() {
      this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      this.setTitle("Test Sound Clip");
      this.setSize(300, 200);
      this.setVisible(true);

      
      try {
         // Open an audio input stream.
         URL url = this.getClass().getClassLoader().getResource("railroad_crossing_bell.wav");
         AudioInputStream audioIn = AudioSystem.getAudioInputStream(url);
         // Get a sound clip resource.
         Clip clip = AudioSystem.getClip();
         // Open audio clip and load samples from the audio input stream.
         clip.open(audioIn);
        
         clip.start();
       
      } catch (UnsupportedAudioFileException e) {
         e.printStackTrace();
      } catch (IOException e) {
         e.printStackTrace();
      } catch (LineUnavailableException e) {
         e.printStackTrace();
      }
      
}

   public static void main(String[] args) {
      new SoundClipTest();
   }
}