#include "stdio.h"

#define MAX_BITS 32
#undef NULL
#define NULL 0

void print_binary(int); // function prototype

int main()
{
	int num;
	printf("enter a valid positive (32-bit) integer: ");
	scanf("%d", &num);
	print_binary(num);
	printf("\n");
	return 0;
}

void print_binary(int val)
{
	int array[MAX_BITS]; // this is how you declare an array

	//initialize counter in for loop C99 error
	int i = 0;
	//initialize pointer
	int *arrayPtr;

	//set pointer
	arrayPtr = array;

	//turning integer into binary and reversing order
	while (val > 0)
	{
		//this "x"  counter allows us to move to the next location
		int x  = 1;
		int rem = val % 2;
		*(arrayPtr + ((sizeof(arrayPtr)/sizeof(*arrayPtr) - x))) = rem;
		x++;
		val /= 2;
	}

	for(i = 0;i<sizeof(arrayPtr)/sizeof(*arrayPtr);i++ )
	{
		//print every element in the array in correct order
 		printf("%d", *(arrayPtr + i));
	}
}

