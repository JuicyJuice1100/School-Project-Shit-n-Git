#include "stdio.h"

#define MAX_BITS 32

void print_binary(int); // function prototype

int main()
{
	int num;
	printf("enter a valid positive (32-bit) integer: ");
	scanf("%d", &num);
	print_binary(num);
	printf("\n");
	return 0;
}

void print_binary(int val)
{
	int array[MAX_BITS]; // this is how you declare an array
	int x = 0, y;


		//convert each digit to binary
		while (val > 0)
		{
			int rem = val % 2;
			array[x] = rem;
			val /= 2;
			x++;
		}

		//print the reverse of the array
		for(y = x; y >= 0; y--)
		{
			printf("%d", array[y]);
		}
}

