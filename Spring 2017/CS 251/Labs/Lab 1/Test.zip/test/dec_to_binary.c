#include "stdio.h"

#define MAX_BITS 32

void print_binary(int); // function prototype

int main()
{
	int num;
	printf("enter a valid positive (32-bit) integer: ");
	scanf("%d", &num);
	print_binary(num);
	printf("\n");
	return 0;
}

void print_binary(int val)
{
	int array[MAX_BITS]; // this is how you declare an array
	while (val > 0)
	{
		int rem = val % 2;
		printf("%d", rem);
		val /= 2;
	}
}

