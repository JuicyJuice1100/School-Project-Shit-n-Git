#include "stdio.h"
#include "math.h"
#include "string.h"

#define MAX_BITS 32

int main()
{
	int the_bits[MAX_BITS];
	int the_value;
	int count = 0;
	int sum = 0;
	int index;

	printf("Enter up to a 32-bit integer in two's complement: ");

	//Extract the bits into the_bits array:
	char input[MAX_BITS + 1];
	scanf("%s", input); //Read in a string
	int i, len = strlen(input); //length of the string
	for(i = 0; i < len; i++)
	{
		the_bits[i] = input[i] - '0'; //convert chars to numeric digits
	}
	//index = index in array
	index = strlen(input) - 1;

	if(the_bits[0] == 0) //Most-significatn bit 0, so positive
	{
		while(index  > 0)
		{
			sum += the_bits[index--] * (int)(pow(2, count++));
		}
		printf("%d", sum);
	}
	else //most-significant bit 1, so negative
	{
		//subtract 1 from input
		while(the_bits[index] == 0)
		{
			the_bits[index--] = 1;
		}
		the_bits[index] = 0
;
		//printf("%d\n", the_bits[index]);
		index = strlen(input) - 1;
		//printf("%d\n%d\n", index, the_bits[index]);

		//complement the array
		while(index >= 0)
		{
			if(the_bits[index] == 1)
			{
				the_bits[index] = 0;
				//printf("%d\n", the_bits[index]);
			}
			else
			{
				the_bits[index] = 1;
				//printf("%d\n", the_bits[index]);
			}
		sum += the_bits[index--] * (int)(pow(2, count++));
		printf("%d\n", sum);
		}
		printf("-%d", sum);
	}
	return 0;
}
