#include "stdio.h"
#include "math.h"
#include "string.h"

#define MAX_BITS 32

int main()
{
	int the_bits[MAX_BITS];
	int the_value;
	int count = 0;
	int sum = 0;
	int index;

	printf("Enter up to a 32-bit integer in two's complement: ");

	//Extract the bits into the_bits array:
	char input[MAX_BITS + 1];
	scanf("%s", input); //Read in a string
	int i, len = strlen(input); //length of the string
	for(i = 0; i < len; i++)
	{
		the_bits[i] = input[i] - '0'; //convert chars to numeric digits
	}
	//index = index in array
	index = strlen(input) - 1;

	if(the_bits[0] == 0) //Most-significatn bit 0, so positive
	{
		while(index  > 0)
		{
			//getting positional notation
			sum += the_bits[index--] * (int)(pow(2, count++));
		}
		printf("%d\n", sum);
	}
	else //most-significant bit 1, so negative
	{
		//subtract 1 from input(in binary)
		while(the_bits[index] == 0)
		{
			the_bits[index--] = 1;
		}
		//continuation of subtracting 1 from input (in binary)
		the_bits[index] = 0;
		index = strlen(input) - 1;

		//complement input (in binary)
		while(index >= 0)
		{
			if(the_bits[index] == 1)
			{
				the_bits[index] = 0;
			}
			else
			{
				the_bits[index] = 1;
			}

		//getting positional notation
		sum += the_bits[index--] * (int)(pow(2, count++));
		}
		printf("-%d\n", sum);
	}
	return 0;
}
