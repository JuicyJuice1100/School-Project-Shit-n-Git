DROP VIEW getChildren;
DROP VIEW getParents;
DROP TABLE Relation;
DROP TABLE Event;
DROP TABLE Person;