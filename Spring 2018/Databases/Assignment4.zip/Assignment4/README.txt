Justin Espiritu & Jason Price
---------------------------------------------------------
Bulk Loading Data Process:
- In order to enter all of our data into the database we decided to manually
  input our data since the database was not super big and it would've taken
  longer to write the JDBC java programs to have it automatically bulk load
  our data.
- In order to accomplish this we just made a number of insert statements 
- After this, we began to make our queries and realized the design of our
  database was too compliacted so we had to go back and simplify our design.
  If you would like to see our new design we can send a new E/R diagram to
  you...
- After our redesign and resinsertion and our data we were then able to
  complete the queries you assigned in a much easier fashion.
- For two of the queries we did create a view since you said it was allowed
