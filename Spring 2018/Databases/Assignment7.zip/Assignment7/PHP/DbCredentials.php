<?php
    define("DB_SERVER", "localhost");
    define("DB_USER", "espirj96");
    define("DB_PWD", "j370796");
    define("DB_NAME", "espirj96");
?>