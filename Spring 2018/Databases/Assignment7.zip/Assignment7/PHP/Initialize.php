<?php
    require_once('Database.php');
    require_once('Queries.php');
    date_default_timezone_set('America/Chicago');
    $db = db_connect();
?>