  <footer>
    <hr />
    Visits: A (<?php echo $_COOKIE['A']; ?> ) /
            B (<?php echo $_COOKIE['B']; ?> ) /
            C (<?php echo $_COOKIE['C']; ?> )
  </footer>
