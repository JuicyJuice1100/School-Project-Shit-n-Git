/*
 * Assumptions:  Must enter valid date in following format: mm-dd-yyyy
 */
package lab1;

/**
 *
 * @author espirj96
 */
public class Lab1Main {
    public static void main(String[] args){
        //UserCalendarInput userCalendarInput = new UserCalendarInput(); 
        DayCalculator calculate = new DayCalculator();
    }
}
