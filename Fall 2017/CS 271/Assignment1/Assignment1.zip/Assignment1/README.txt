Assignment1
@Author Justin Espiritu
@Date 10/18/2017
@Discription Simple program to allow user to input variables and evaluate expression by converting an infixed expression to a postfixed

To Run:
Run the Assignment1.java file
To input a Variable insert variable name followed by "=" followed by value (Ex. A = 25) Will correct any spaces
To evaluate an expression insert an expression using doubles/ints, variables inserted already, and the following "+-*/()" (Ex. A + 25 *(54 + B) + 100)
To Exit type anything without a "+-*()="
