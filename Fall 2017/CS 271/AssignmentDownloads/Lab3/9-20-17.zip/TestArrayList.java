public class TestArrayList
{
    public static void main( String [ ] args )
    {
        MyList<Integer> lst = new MyArrayList<>();

        for( int i = 0; i < 10; i++ )
                lst.insert( i );
        for( int i = 20; i < 30; i++ )
                lst.insert( 0, i );

	System.out.println( lst );
	System.out.println( "Size="+lst.size( ) );

        System.out.println("Removing first, "+lst.remove(0));
        System.out.println(lst);
        System.out.println("Removing last, "+lst.remove(lst.size()-1));
        System.out.println(lst);
        System.out.println("Removing index 6, "+lst.remove(6));
        System.out.println(lst);
        System.out.println("Removing 25");
        lst.remove(new Integer(25));
        System.out.println(lst);
        System.out.println("Size="+lst.size());

 	System.out.println("Get 3rd element:"+lst.get(2));
 	System.out.println("Contains 16:"+lst.contains(16));
 	System.out.println("Contains 20:"+lst.contains(20));

    }
}