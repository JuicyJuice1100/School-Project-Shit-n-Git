
public class MyListException extends RuntimeException {
	public MyListException(String s){
			super(s);
	}
}
