
public class MyArrayList<T> implements MyList<T> {
    private T[] array;
    private int size;
    
    @SuppressWarnings("unchecked")
    public MyArrayList(){
        array = (T[])(new Object[5]);
        size = 0;
    }
    
    @SuppressWarnings("unchecked")
    private void resize(){  //O(n)
        T[] tempArray = (T[])(new Object[array.length*2]);
        
        for (int i=0; i<array.length; i++)
            tempArray[i] = array[i];
            
        array = tempArray;
    }
    
    public void insert(T element){ //O(1), ignore resize 
        if (size==array.length)
            resize();
        array[size] = element;
        size++;
    }
    
   public void insert(int index, T element) throws MyListException{
       //O(n), ignore resize occurs
        if (size==array.length)
        if (index < 0 || index > size)
            throw new MyListException("Invalid index");
            
        if (size==array.length)
            resize();
        
        for (int i = size -1; i >=index; i--) 
            array[i+1] = array[i];
        
        array[index] = element;
        size++;      
   }
    
   public T get(int index)throws MyListException{ //O(1)
        if (index < 0 || index > size-1)
            throw new MyListException("Invalid index");
        
        return array[index];
 
    }
    
   public boolean contains(T element){ //O(n)
       for (int i=0; i<size; i++){
           if (array[i].equals(element))
                return true;
        }
       
       return false;
    }
    
   public T remove(int index)throws MyListException{
       //Exercise ...
       return null;
    }
    
   public boolean remove(T element){ //O(n)
        int index =-1;
        for (int i=0; i<size; i++){
           if (array[i].equals(element)){
               index = i;
               break;
            }
        }
        //position of element is i:
        if (index > -1){
            for (int i = index; i<size-1;i++)
                array[i] = array[i+1];
            size--;
            return true;
        }
        return false;
    }
    
   public int size(){
       return size;
    }  
    
   public String toString(){ //O(n)
       StringBuilder sb = new StringBuilder("[");
       for (int i=0; i<size; i++){
            sb.append(array[i]);
            sb.append(" ");
        }
       sb.append("]");
       return sb.toString();
    }
    

}










