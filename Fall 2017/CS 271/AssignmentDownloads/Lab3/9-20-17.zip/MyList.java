public interface MyList<T>
{
   public void insert(T element);
   public void insert(int index, T element) throws MyListException;
   public T get(int index)throws MyListException;
   public boolean contains(T element);
   public T remove(int index)throws MyListException;
   public boolean remove(T element);
   public int size();  
}
